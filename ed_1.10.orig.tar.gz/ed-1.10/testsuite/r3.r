r r3.ed
1;/H/+d
w r3.o
