3d
e e1.ed
1,2d
w e1.o
